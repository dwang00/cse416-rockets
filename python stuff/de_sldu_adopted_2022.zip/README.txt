2022 Delaware Senate Plan (State Legislative Districts Upper [SLDU])

##Redistricting Data Hub (RDH) Retrieval Date
10/10/2022

##Sources
This dataset was retrieved from the [Delaware General Assembly](https://legis.delaware.gov/Redistricting/2022FinalSenateDistricts)
The file is titled "2022 Revised Senate District Shape Files authorized HB 335 (Downloadable .zip File)".

The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile for Delaware's Senate Districts ("DESenate22.shp"), and supporting files.

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org