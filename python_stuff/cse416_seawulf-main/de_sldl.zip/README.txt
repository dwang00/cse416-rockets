2022 Delaware State House of Representatives Plan (State Legislative Districts Lower [SLDL])

##Redistricting Data Hub (RDH) Retrieval Date
10/10/2022

##Sources
This dataset was retrieved from the [Delaware General Assembly](https://legis.delaware.gov/Redistricting/2022FinalHouseDistricts)
The file is titled "2022 Revised House District Shape Files authorized HB 335 (Downloadable .zip File)".

The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
Enclosed in this zip file the shapefile for Delaware's House of Representatives Districts ("March 2022 Redistricting Clean Up File.shp"), and supporting files.

To keep track of a state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org