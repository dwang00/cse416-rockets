2021 Alabama State House Plan enacted 11/4/2021

##Redistricting Data Hub (RDH) Retrieval Date
11/05/2021

##Sources
This dataset was received from the Alabama Senate Reapportionment Office by request

##Processing
The RDH retrieved the data from the source listed and did not modify any of the data.

##Additional Notes
To keep track of state's adopted maps, go to All About Redistricting https://redistricting.lls.edu/
For any additional questions, please email info@redistrictingdatahub.org